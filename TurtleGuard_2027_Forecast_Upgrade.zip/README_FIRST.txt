TurtleGuard 2027 upgrade

1. Back up the current project.
2. Copy files inside TurtleGuard_BeachPriority/ into your existing TurtleGuard_BeachPriority folder, merging folders (do not delete existing files).
3. Keep your nesting_counts.csv, forecast_results.json, and the old source files until running the new script.
4. From TurtleGuard_BeachPriority run:
   ..\turtleguard_timesfm\.venv\Scripts\python.exe scripts\run_all.py --skip-weekly
5. Wait for all real TimesFM backtests and 2027 forecasts to finish, then serve site as usual.

See FORECAST_2027_NOTES.md for sources, controls, and scientific limitations.
