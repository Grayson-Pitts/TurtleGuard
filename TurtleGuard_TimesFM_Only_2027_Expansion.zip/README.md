# TurtleGuard — TimesFM-Only Forecasting & Mote History Expansion

This patch is based on the previously tested 2027 TurtleGuard forecasting code. It **does not** replace your entire repository. Back up your working repo and copy `TurtleGuard_BeachPriority` into the corresponding folder, overwriting the listed matching files. Keep your existing `turtleguard_timesfm/.venv` and other scripts.

## Quick start (Windows PowerShell)

From `TurtleGuard/TurtleGuard_BeachPriority`:

```powershell
..\turtleguard_timesfm\.venv\Scripts\python.exe scripts\run_all.py --skip-weekly
```

This produces the **actual** TimesFM 3 forecasts for the 2027 nesting season and rebuilds `site/data.json` and `site/priorities.json`. There are no pretrained/model predictions bundled into the ZIP; **don't reuse earlier JSON outputs**. TimesFM model weights remain in your local installation.

Start the website:

```powershell
..\turtleguard_timesfm\.venv\Scripts\python.exe -m http.server 8000 -d site
```

Open <http://localhost:8000> and hard-refresh (`Ctrl+F5`).

If you prefer to **exclude unfinished 2026 Mote data** from the predictions:

```powershell
..\turtleguard_timesfm\.venv\Scripts\python.exe scripts\run_all.py --skip-weekly --exclude-provisional-2026
```

You can keep the weekly PDF workflow separate; it is not involved in the 2027 beach ranking. This patch skips unrelated weekly report import unless `--include-weekly-import` is explicitly passed.

## What's included

- `data/nesting_counts.csv` — expanded to 2009–2026 for five Mote beaches, while preserving the Boca Raton, Canaveral, and Volusia source series.
- `data/mote_annual_selected_sources.csv` — the chosen nesting count, supporting report, and status for each Mote beach/year.
- `data/mote_candidates_audit.csv` — all extracted and preexisting candidates, with sources.
- `data/mote_conflicts_review.csv` — 29 conflicting location/year counts found in the initial merge; highest recorded nest count chosen as requested.
- `data/mote_annual_reports/*.pdf` — the 17 user-provided PDFs used to generate the selected dataset.
- `scripts/merge_mote_annual_reports.py` — reproducible, source-specific importer (supports the attached report layouts, refuses unknown layouts). To reprocess reports later, run `python scripts/merge_mote_annual_reports.py` using a Python environment with `pymupdf` installed. **Do not confuse the report merger with the weekly PDF importer.**
- `scripts/forecast_2027.py` — direct TimesFM-only forecasts for 2027; historical baselines remain for comparative backtests, not for selecting displayed results.
- `scripts/build_dashboard_data.py`, `scripts/build_beach_priorities.py` — refuse stale baseline-selected forecasts and use the new direct TimesFM results.
- `site/index.html` — retains the layout and styles, but reads `priority_score` from density-adjusted Python output, rather than recomputing rank-based colors.
- `data/beach_lengths.csv`, `site/beach_areas.geojson` — unchanged existing length estimates and approximate coastline geometries.
- `tests/test_timesfm_only_update.py` — offline validations.

## Data limitations

**Nest counts, not unique turtles.** False crawls are excluded. Longboat Key's Manatee and Sarasota sections are added to represent the whole key. For the 2019 final report, leatherback nests are included where explicitly listed. Small unlocated counts, such as the two 2014 Kemp's ridley nests listed only in the report footnote, are **not** arbitrarily assigned to a beach.

**Conflicts:** Count discrepancies are resolved by taking the highest nest count for each matching beach/year, as requested; not by adding conflicting reported values. The discrepancy log preserves the alternative numbers and reports. Larger counts are not automatically proof of a more accurate or final dataset; review flagged differences before using this in operational conservation decisions.

**2009–2014:** Early Mote annual figures come from cumulative weekly summaries with different reporting end dates (some end in August or September), not verified final season totals. In particular, the unusually similar 2012/2013 values should be reviewed if a better final archive is obtained.

**2026:** The Week 42 report provides *season-to-date* counts. On October 24, 2026, these cannot be described as final-year totals. They are included by default to match the requested 2009–2026 window, with a provisional flag, and can be excluded via `--exclude-provisional-2026`.

**Forecast quality:** Even with 18 Mote observations, there is no guarantee TimesFM outperforms simpler methods. Historical backtests are produced for transparent evaluation. The map's score is a relative **nest-density inspection index**, not a measured debris hazard or guaranteed conservation benefit. Volusia's coastline length is a provisional mismatch-prone proxy; all drawn coastline lines are approximate, not surveyed outlines.

## Tests conducted

- Parser read all 17 PDFs; conflicts were audited rather than silently summed.
- All five Mote beaches have consecutive 2009–2026 series (18 annual data points each).
- Offline mock-forecaster tests confirmed 14 TimesFM-only outputs, eight regions, 2027 target year, provisional flag, and the correct 1-, 2-, or 3-year horizon.
- An isolated, synthetic-output end-to-end build confirmed that dashboard/priority writers accept TimesFM-only results and apply nests-per-mile scoring. **Those synthetic predictions are not included in this release.**
- JavaScript syntax was checked. This environment did **not** execute the actual model weights or validate the website visually in your browser.
